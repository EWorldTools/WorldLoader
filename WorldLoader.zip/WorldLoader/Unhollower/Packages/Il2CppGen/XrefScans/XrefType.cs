namespace WorldLoader.Il2CppGen.Internal.XrefScans;

public enum XrefType
{
    Global,
    Method
}
