﻿using System;

namespace WorldLoader.Il2CppGen.Internal.Host;

public interface IHostComponent : IDisposable
{
    void Start();
}
