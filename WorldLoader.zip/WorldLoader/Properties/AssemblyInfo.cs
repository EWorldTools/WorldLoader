﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("WorldLoader")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("_1254")]
[assembly: AssemblyProduct("WorldLoader")]
[assembly: AssemblyCopyright("Furry Balls Inc")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("cfe72319-45e3-4e7f-9635-c533c5d66ddf")]
[assembly: AssemblyFileVersion("1.0.0.0")]
